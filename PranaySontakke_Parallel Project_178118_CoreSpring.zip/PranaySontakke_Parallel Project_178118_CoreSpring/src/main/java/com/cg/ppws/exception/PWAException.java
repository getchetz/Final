package com.cg.ppws.exception;

public class PWAException extends Exception{

	public PWAException(String message) {
		super(message);
	}

}
