package com.cg.ppws.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.ppws.bean.CSAccount;
import com.cg.ppws.bean.CSTransaction;
import com.cg.ppws.dao.CSAccountRepository;
import com.cg.ppws.dao.CSTransactionRepository;

import oracle.net.aso.a;

@Service
public class CSAccountService {

	@Autowired
	CSAccountRepository repoAccount;
	@Autowired
	CSTransactionRepository repoTr;

	
	Optional<CSAccount> option;
	CSTransaction transaction;
	CSAccount account;

	public String addAccount(CSAccount account1) {
		
		repoAccount.save(account1);
		addTransaction(account1,account1.getBalance(),"account created");
		return "your Account Id is: "+account1.getId();
	}


	public boolean validateLogin(int acId, String p) {
		account=repoAccount.findById(acId).get();

		if(account!=null)
		{
			if(account.getPassword().equals(p)) {
				return true;
			}
			else {
				return false;
			}
		}
		else{
			return false;
		}
	}

	
	
	public CSAccount getAccount(CSAccount account1) {

		option =repoAccount.findById(account1.getId());
		if(option.isPresent())
			return option.get();
		return null;
	}


	public CSAccount deposit(double amount, int id) {

		account=repoAccount.findById(id).get();
		account.setBalance(account.getBalance()+amount);
		repoAccount.save(account);
		addTransaction(account,amount,"credited to account");
		return account;
	}

	public CSAccount withdraw(double amount, int id) {

		account=repoAccount.findById(id).get();
		account.setBalance(account.getBalance()-amount);
		repoAccount.save(account);

		addTransaction(account,amount,"deposited from account");
		return account;
	}


	public CSAccount bankToWallet(double amount, int id) {
		account=repoAccount.findById(id).get();
		if(account.getBalance()>=amount) {
			account.setBalance(account.getBalance()-amount);
			account.setWallet(account.getWallet()+amount);
			repoAccount.save(account);

			addTransaction(account,amount,"added in wallet");
		}
		return account;
	}


	public CSAccount walletToWallet(double amount, int id, int receiver) {

		account=repoAccount.findById(id).get();
		option=repoAccount.findById(receiver);
		CSAccount receiveAccount=option.get();
		receiveAccount.setWallet(receiveAccount.getWallet()+amount);
		account.setWallet(account.getWallet()-amount);
		repoAccount.save(account);
		repoAccount.save(receiveAccount);
		addTransaction(receiveAccount,amount,"received in wallet");

		addTransaction(account,amount,"paid from wallet");
		return account;
	}


	public boolean isAccount(int id) {
		option=repoAccount.findById(id);
		if(option.isPresent()) 
			return true;
		else
			return false;
	}


	public CSAccount walletToBank(double amount, int id) {
		account=repoAccount.findById(id).get();
		account.setWallet(account.getWallet()-amount);
		account.setBalance(account.getBalance()+amount);
		repoAccount.save(account);

		addTransaction(account,amount,"wallet to bank");
		return account;
	}
	
	public void addTransaction(CSAccount account1,Double amount,String operation) {
		transaction=new CSTransaction(account1.getId(), Date.valueOf(LocalDate.now()), account1.getBalance(), amount, account1.getWallet(), operation);
		repoTr.save(transaction);
	}
	
	public List<CSTransaction> getTransactions(int id) {
		List<CSTransaction> list = new ArrayList<CSTransaction>();
		repoTr.findAll().forEach(list::add);
		list=list.stream().filter(trans->trans.getAccountId()==id).collect(Collectors.toList());
		
		return list;
	}


	public CSAccount getAccount(int acId) {
		// TODO Auto-generated method stub
		return repoAccount.findById(acId).get();
	}


	public Iterable<CSAccount> getAll() {
		// TODO Auto-generated method stub
		return repoAccount.findAll();
	}
}
